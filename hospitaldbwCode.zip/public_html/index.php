<html>
<head>
<style>
h1 {text-align: center;}
p {text-align: center;}
</style>
</head>
<body>

<h1>Main page</h1>
<div align = 'center'>

<?php
    $message = "This is the first page";
    echo $message;
?>
<br>
<br>
<a href="https://hospitaldbw.000webhostapp.com/login.php">
       <button>Login</button>
     </a>
</div>
</body>
</html>