To run this you need to download an apache server and a MySQL server like 
XAMPP: https://www.apachefriends.org/index.html
or appserv: https://www.appserv.org/en/.
Ufortunately you have to change the website since the websites were hosted by my local host.
Go to your local host website and specify the main.php to start the wbesite.
you will be able to navigate back and forth with the provided buttons.

Note: in the login page there are buttons and a login bar. The idea is to implement ONLY
the login bar and remove the buttons once the connection to MySQL is established. 
but for the sake of navigating between pages I added buttons to show the complete layout/functionalities