<html>
<head>
<style>
h1 {text-align: center;}
p {text-align: center;}
</style>
</head>
<body>

<h1>Administrator page</h1>
<div align = 'center'>

<?php
    $message = "This is the administrator page";
    echo $message;
?>
<br><br><br><br>
<a href="https://hospitaldbw.000webhostapp.com/supplier.php">
       <button>Supplier</button>
</a>
<br><br><br><br>
<a href="https://hospitaldbw.000webhostapp.com/employee.php">
       <button>Employee</button>
</a><br><br><br><br>
<a href="https://hospitaldbw.000webhostapp.com/patient.php">
       <button>Patient</button>
</a>
<br><br><br><br><br><br><br><br><br><br><br><br>
<a href="https://hospitaldbw.000webhostapp.com/processLogout.php">
       <button>Back to login</button>
     </a>
</div>
</body>
</html>